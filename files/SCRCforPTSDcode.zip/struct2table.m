function table = struct2table(struct,headerRow)
% turns a 1 x N struct into a N column table by making the left column the field
% names and the right column the field values
% the variable headerRow is either a cell vector of the header columns or
% the index of the feild that contains the data;
fList = fieldnames(struct);

if iscell(headerRow)
    table(1,:) = headerRow;
else
    table(1,:) = {' ', struct.(fList{headerRow})};
    fList(headerRow) = [];
end


for k = 1:length(fList)
    table(k+1,1) = fList(k);
    val = struct(1).(fList{k});
    if isnumeric(val)
        val =num2str(val);
    end
    table{k+1,2} = val;
    
end

if length(struct)>1
    for ii = 2:length(struct)
        for k = 1:length(fList)
            
            val = struct(ii).(fList{k});
            if isnumeric(val)
                val =num2str(val);
            end
            table{k+1,ii+1} = val;
            
            
        end
    end
end


%% Sample development code
% markers.posMarker = posMarker;
% markers.posMarkerC = posMarkerC;
% markers.posMarkerT = posMarkerT;
%
% markers.negMarker = negMarker;
% markers.negMarkerC = negMarkerC;
% markers.negMarkerT = negMarkerT;

% mList = fieldnames(markers);
% sel = 1;
% struct = markers.(mList{sel});