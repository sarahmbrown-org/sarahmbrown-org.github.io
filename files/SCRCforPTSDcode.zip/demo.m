%% Code to generate synthetic results complilmentary to AAAI 15 paper
% human subject data from the paper is proprietary and cannot be shared
%
%%  Script settings
saveOn = true; % flag for saving figures, results are always saves

% how many lambda values to test on
L=20;

% how many folds (LOO always runs)
K = 7;

% constants
% N = # subjects
% D = # features
N = 38;
D = 15;

% how many features do not impact yp
offFeatRate = .6;
% how many have noise added
weakFeatRate = .1;
% how strong is the noie
weakNoiseLevel = .05;

%% Create a place to save the results

dateStamp = date;
saveDir = [pwd '\scrcDemoResults' dateStamp '\'];
mkdir(saveDir)

%% Generate Synthetic Data
% random X on (-1,1)
X = 2*rand(N,D)-1;

% set number of features to not be used at all and choose which
noffFeatures = ceil(offFeatRate*D);
offFeatures = randsample(D,noffFeatures);

% max beta
betaMax = 30;

% set tru beta with some zeros
betaTrue  = betaMax*(2*rand(D,1)-1);
betaTrue(offFeatures) = 0;

% set true yp
ypTrue = X*betaTrue;

% make some of the features less useful by addign noise
nWeakFeatures = ceil(D*weakFeatRate);
onFeatures = setdiff(1:D,offFeatures);
weakFeatures = randsample(onFeatures,nWeakFeatures,1);
% generate and add noise only in rows corresponding to the weak fetures
noise = zeros(N,D);
noise(:,weakFeatures) = randn(N,nWeakFeatures)*weakNoiseLevel;
X = X + noise;

% shift so that ~50% of samples are below diagnosis threshold and ~75% of
% healthy have a 0 score.  this mimics the real dataset roughly
thIdx = ceil(.5*N);
zIdx = ceil(.75*thIdx);
ypSort = sort(ypTrue);

ypTrue = ypTrue - ypSort(zIdx);  %shift all so that the right proportion are zeros
th = ypSort(thIdx) - ypSort(zIdx); % set the diagnosis threshold

% generate yc by flooring and saturating yp
yc = floor(ypTrue);
yc(yc<0) =0;


%% create a numeric and text-based grouping variables for diagnosis
status = (yc >th) +1;
diagnosis = cell(size(status));
diagnosis(status==1) = repmat({'class A'},sum(status==1),1);
diagnosis(status==2) = repmat({'class B'},sum(status==2),1);


%% Construct design matrices for formulation as

delta = 1;

% normalize data feature wise
%  subjects were previously normalized within subject for data from the
%  same channel, but different time points here we scale features so that
%  various channels are on the same scale (ECG vs GSR)
Xmin = min(X);
Xrange = max(X) -Xmin;
X = ((X - ones(N,1)*Xmin)./(ones(N,1)*Xrange) - .5)*2;

% create the X1 = X_{bar{Z}} and X2 = X_{Z} matrices
X1 = X(yc>0,:);
y1 = yc(yc>0);
yd = ((yc>0)-.5)*floor(mean(y1));
X2 = X(yc==0,:);
[N1,~] = size(X1);
[N2,~] = size(X2);

% add a column of ones to the feature data to allow an offset term
X = [X ones(N,1)];
X1 =[X1 ones(N1,1)];
X2 = [X2 ones(N2,1)];

%% Set Constants used in optimization algorithms
% these are chosen from literature

% rho is the augmented Lagrangian parameter.
rho = 1;
% alpha is the over-relaxation parameter (typical values for alpha are
% between 1.0 and 1.8).
alpha = 1.5;


%% Solve at one sample lambda
% this cell is used in testing that the function works
% it is also useful for choosing an acceptabl eoperating point for the
% constants used in determining the stopping point of the algorithms


% set lambda max values from data
lambda_maxLASSO = norm( X'*yc, 'inf' );
lambdaTest1  = .05*lambda_maxLASSO;
lambda_maxSCRC = norm( [X1'*y1; X'*yd], 'inf' );
lambdaSCRC  = .02*lambda_maxSCRC;


% regular lasso
[betaLASSO, history1] = LASSOviaADMM(X, yc,lambdaTest1, rho, alpha,1);
%separated
[betaSCRC, history3] = SCRCviaADMM(X1, y1, X, yd , lambdaSCRC, rho,0);



%  Plot simple results
% for visual confirmation that the function is working & data fits
SP = 2;
hsave = figure;
subplot(1,SP,1)
hold off
gscatter(yc, X*betaLASSO,diagnosis)
hold on
plot([0 140], [0 140],'k')
title('Lasso')


subplot(1,SP,2)
hold off
gscatter(yc, X*betaSCRC,diagnosis)
hold on
plot([0 140], [0 140],'k')
title('SCRC')

% convert 1 - trauma, 2= ptsd, to 0= trauma 1 = ptsd (above threshold)
testStatus = status-1;

% compute scores for the fit to the whole data set
allfitRes(1) = clinicalScoreFitPerformance(betaLASSO,X,yc,testStatus,'all data LASSO');
allfitRes(2) = clinicalScoreFitPerformance(betaSCRC,X,yc,testStatus,'all data SCRC');

initCompare = struct2table(allfitRes,{'metric', 'LASSO', 'SCRC'});
initCompare(11,:) = []; % delete ROC row
tmp = cell2dataset(initCompare)
export(tmp, 'file',[saveDir 'initcompare.csv'],'delimiter',',')

if saveOn
    print(hsave,[saveDir  'alldata05lambda.eps'],  '-depsc2')
end


%% Test over a range of lambda values chosed to match the whole range of the data


% create a larger range of lambda test values that spans what both
% algorithms need to run to completion

lambda_maxMax = max(lambda_maxSCRC,lambda_maxLASSO);
lambda_maxMin = min(lambda_maxSCRC,lambda_maxLASSO);
% coefficients on lambdd_max below can be chagned depending on data
% should be large enough range such that solutions that include all
% features and no features are included
lambda = logspace(log10(.005*lambda_maxMin), log10(.5*lambda_maxMax),L);

%% %% LOO Cross validated for various lambda solution for stability

% allocate memory
lassoBetaGen = zeros(D+1,L,N);
consensusBetaGen = zeros(D+1,L,N);

idxLOO = 1:N;
% Cross validation loop
%   generate the data needed for generalization-based features and compute
%   fit based results for each solution over the whole data set... the
%   <method>PerfGenAll solutions aren't used for any presentation, only for
%   troubleshooting/exploration
for kk = 1:N
    % create test & train sets for this fold
    test = idxLOO ==kk;
    train = ~test;
    Xtrain = X(train,:);
    Xtest = X(test,:);    
    ydtrain = yd(train);
    yctrain = yc(train);
    yctest = yc(test);
    Ntrain = sum(train);
    Xnztrain = Xtrain(yctrain>0,:);
    ycnztrain = yctrain(yctrain>0);
    X2train = Xtrain(yctrain==0,:);
    
    %lambda loop
    for ii = 1:length(lambda)
        display(['Fold ' num2str(kk) '/' num2str(N) ' lambda idx ' num2str(ii) '/' num2str(L)])
        [lassoBetaGen(:,ii,kk), lassoHistory(ii,kk)] = LASSOviaADMM(Xtrain, yctrain,lambda(ii), rho, alpha,1);
        lassoPerfGenAll(ii,kk) = clinicalScoreFitPerformance(lassoBetaGen(:,ii,kk),X,yc,testStatus,...
            ['lasso LOO ' num2str(kk) 'th fold lambda = ' num2str(floor(lambda(ii)*100)/100)]);
        
        % try- catch to set zero solutions for fold-lambda cases where
        % there is no solution or a solution of zeros
        try
            [consensusBetaGen(:,ii,kk), history3] = SCRCviaADMM(Xnztrain, ycnztrain,Xtrain, ydtrain, lambda(ii), rho,1);
            consensusPerfGenAll(ii,kk) = clinicalScoreFitPerformance(consensusBetaGen(:,ii,kk),X,yc,testStatus,...
                ['consensus LOO ' num2str(kk) 'th fold lambda = ' num2str(floor(lambda(ii)*100)/100)]);
            
        catch
%             consensusBetaGen(:,ii,kk) = zeros(size(consensusBetaGen(:,ii-1,kk)));
            consensusPerfGenAll(ii,kk) = clinicalScoreFitPerformance(betaSCRC,X,yc,testStatus,'dummy value failed solution');
        end
    end
end

%% Compute generalization-based performance
% Compute statistics about the whole set of LOO results relating the the
% stability of the solutions and save in case something happens during the
% next test
consensusGenperf = clinicalScoreGeneralizePerformance(consensusBetaGen,lambda);
lassoGenperf = clinicalScoreGeneralizePerformance(lassoBetaGen,lambda);
timestamp = datestr(now);
timestamp(find(datestr(now)==':')) = [];
save([saveDir '\results' timestamp]) % save here incase it fails below


%% K fold cross validation for fit
% K-fold cross validation as set at top of script

% set cross validation loop
idx = crossvalind('Kfold',testStatus,K);

% allocate memory
lassoBeta = zeros(D+1,L,K);
consensusBeta = zeros(D+1,L,K);


% Cross validation loop
%   find solutions for each fold and measure performance in each fold
for kk = 1:K
    % create test & train sets for this fold
    test = idx ==kk;
    train = ~test;
    if K == 1
        train = test;
    end
    Xtrain = X(train,:);
    Xtest = X(test,:);
    ydtrain = yd(train);
    yctrain = yc(train);
    yctest = yc(test);
    Ntrain = sum(train);
    Xnztrain = Xtrain(yctrain>0,:);
    ycnztrain = yctrain(yctrain>0);
    
    % test for each lambda
    for ii = 1:length(lambda)
        display(['Fold ' num2str(kk) '/' num2str(K) ' lambda idx ' num2str(ii) '/' num2str(L)])
        
        % Lasso solution
        [lassoBeta(:,ii,kk), lassoHistory(ii,kk)] = LASSOviaADMM(Xtrain, yctrain,lambda(ii), rho, alpha,1);
        % Lasso perofrmance
        lassoPerfFold(ii,kk) = clinicalScoreFitPerformance(lassoBeta(:,ii,kk),Xtest,yctest,testStatus(test),...
            ['lasso ' num2str(K) 'fold ' num2str(kk) 'th fold lambda = ' num2str(floor(lambda(ii)*100)/100)]);
        
        
        % try- catch to set zero solutions for fold-lambda cases where
        % there is no solution
        try
            [consensusBeta(:,ii,kk), history3] = SCRCviaADMM(Xnztrain, ycnztrain, X, ydtrain, lambda(ii), rho,1);
            consensusPerfFold(ii,kk) = clinicalScoreFitPerformance(consensusBeta(:,ii,kk),Xtest,yctest,testStatus(test),...
                ['scrc ' num2str(K) 'fold ' num2str(kk) 'th fold lambda = ' num2str(floor(lambda(ii)*100)/100)]);
                       
        catch
            consensusPerfFold(ii,kk) = clinicalScoreFitPerformance(betaSCRC,X,yc,testStatus,'dummy value failed solution');
        end
    end
end

%% save final results

timestamp = datestr(now);
timestamp(find(datestr(now)==':')) = [];
save([saveDir '\results' timestamp])

%% Plot performance from K-fold in quad plot
% note subplot(2,2,x) is not used to create extra space and adjust for
% onlyl plotting the legend once

% %set which data to use
SCRCres = consensusPerfFold;
LASSOres = lassoPerfFold;

%  for testing only
% SCRCres = consensusPerfGenAll;
% LASSOres = lassoPerfGenAll;



hsave = newFmtFigure('presentationfull');
% ---------------------------Plot MSE_NZ-----------------------------------
sf1 = newFmtSubplot(9,2,[1 3 5],'presentationfull');
hmsenz = plotPerformanceCvalMeanSTD(LASSOres, SCRCres,...
    {'LASSO'  'SCRC'},'MSEnz','MSE_{nz} for held out',lambda,sf1,'fit',false);
% Add a naive value, MSE ( mean for all)
hold on
naive = mean((yc-mean(yc)).^2);
plot(log([min(lambda) max(lambda)]), [naive naive],'-.k')

% ---------------------------Plot AUC -------------------------------------
sf2 = newFmtSubplot(9,2,[2 4 6],'presentationfull');
hauc = plotPerformanceCvalMeanSTD(LASSOres, SCRCres,...
    {'LASSO'  'SCRC'},'auc','Area Under the Curve',lambda,sf2,'fitzo',false);
% Add a naive value, .5
hold on
plot(log([min(lambda) max(lambda)]), [.5  .5],'-.k')

% ---------------------------Plot Spearman Rank----------------------------
sf3 = newFmtSubplot(9,2,[9 11 13],'presentationfull');
hrhoSpearmanRank = plotPerformanceCvalMeanSTD(LASSOres, SCRCres,...
    {'LASSO'  'SCRC'},'rhoSpearmanRank','Spearman Rank',lambda,sf3,'fitzo',false);
hold on
% Naive value is 0 (no correlation) for mean for all
plot(log([min(lambda) max(lambda)]), [0 0],'-.k')

% ---------------------------Plot Error Correlation------------------------
sf4 = newFmtSubplot(9,2,[10 12 14 16],'presentationfull');
herrorCorr = plotPerformanceCvalMeanSTD(LASSOres, SCRCres,...
    {'LASSO'  'SCRC'},'errorCorr','Error Correlation',lambda,sf4,'fitzo');
hold on
% Naive value is 0, yc perfectly predicts the error for a niave choice,
% mean for all
hold on
plot(log([min(lambda) max(lambda)]), [1 1],'-.k')

if saveOn
    print(hsave,[saveDir  'MSEnzANDaucSpearmnasq.eps'],  '-depsc2')
end

%% Generalization

hsave = newFmtFigure('presentationfull');
ll =4;
alpha = 13/14;
sp = newFmtSubplot(2,2,1,'presentationfull');
plotPersistenceHistogram(lassoGenperf,ll,'LASSO',sp);
sp2 = newFmtSubplot(2,2,2,'presentationfull')
plotPersistenceHistogram(consensusGenperf,ll,'SCRC',sp2);


%LASSO fit
newFmtSubplot(2,2,3,'presentationfull');
meanBeta = lassoGenperf.meanBeta(:,ll);
alphaMask = lassoGenperf.featureConsistencyRate(:,ll) > alpha;
persistentBeta = meanBeta.*alphaMask;
gscatter(yc, X*persistentBeta,diagnosis)
hold on
plot([0 140], [0 140],'k')
title(['Fit for Alpha = ' num2str(floor(alpha*100)/100) ' Persistence'])

%SCRC fit
newFmtSubplot(2,2,4,'presentationfull');
meanBeta = consensusGenperf.meanBeta(:,ll);
alphaMask = consensusGenperf.featureConsistencyRate(:,ll) > alpha;
persistentBeta = meanBeta.*alphaMask;
gscatter(yc, X*persistentBeta,diagnosis)
hold on
plot([0 140], [0 140],'k')
title(['Fit for Alpha = ' num2str(floor(alpha*100)/100) ' Persistence'])
