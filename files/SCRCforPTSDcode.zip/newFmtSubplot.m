function h = newFmtSubplot(r,c,idx,type)

h = subplot(r,c,idx);

portion = length(idx)/(r*c);

if portion >=.25
    switch type
        case 'presentation'
            set(gca,'fontsize', 10);
        case 'presentationfull'
            set(gca,'fontsize', 12);
        case 'paper'
            set(gca,'fontsize', 10);
        case 'paperfull'
            set(gca,'fontsize', 10);
        otherwise
            
            
    end
else
    switch type
        case 'presentation'
            set(gca,'fontsize', 8);
        case 'presentationfull'
            set(gca,'fontsize', 8);
        case 'paper'
            set(gca,'fontsize', 8);
        case 'paperfull'
            set(gca,'fontsize', 8);
        otherwise
            
            
    end
end