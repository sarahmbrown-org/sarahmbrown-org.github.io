function h = newFmtFigure(type,varargin)
% create new figures with formatting
scale = .98;


switch type
    case 'presentation'
        scrsz = get(0,'screensize');
        h = figure('position',[1 scrsz(4)/4 scale*scrsz(3) scrsz(4)/2]);
        set(gca,'position',[.05 .2 .95 .7],...
            'fontsize', 10);
    case 'presentationfull'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 scale*scrsz(3) scale*scrsz(4)]);
        set(gca,'fontsize', 14);
    case 'presentationtall'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 .66*scrsz(3) 1.5*scrsz(4)]);
        set(gca,'fontsize', 10);
    case 'presentationhalf'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 scale*scrsz(3) .5*scrsz(4)]);
        set(gca,'fontsize', 12);
    case 'presentationsq'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 .75*scrsz(3) .4*scrsz(4)]);
        set(gca,'fontsize', 12);
    case 'presentationshort'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 .9*scrsz(3) .35*scrsz(4)]);
        set(gca,'fontsize', 8);
    case 'paper'
        scrsz = get(0,'screensize');
        h = figure('position',[1 scrsz(4)/4 .55*scrsz(3) .4*scrsz(4)]);
        set(gca,'position',[.05 .2 .95 .7],...
            'fontsize', 14);
    case 'paperfull'
        scrsz = get(0,'screensize');
        h = figure('position',[83 305 1131 763]);
        set(gca,'fontsize', 14);
    case 'presentationfulleps'
        scrsz = get(0,'screensize');
        h = figure('position',[1 1 scale*scrsz(3) scale*scrsz(4)],'PaperType','usletter');
        set(gca,'fontsize', 12);
    otherwise
        h = figure;
        
end
